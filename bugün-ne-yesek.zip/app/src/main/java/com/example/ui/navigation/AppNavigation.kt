package com.example.ui.navigation

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.RestaurantMenu
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.screens.CategoryScreen
import com.example.ui.screens.FavoritesScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.IngredientSelectionScreen
import com.example.ui.screens.RecipeDetailScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.ShoppingListScreen
import com.example.ui.screens.WeeklyPlanScreen
import com.example.ui.viewmodel.RecipeViewModel

sealed class Screen(
    val route: String,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    object Home : Screen("home", "Anasayfa", Icons.Filled.RestaurantMenu, Icons.Outlined.RestaurantMenu)
    object Shopping : Screen("shopping", "Alışveriş", Icons.Filled.ShoppingCart, Icons.Outlined.ShoppingCart)
    object Plan : Screen("plan", "Haftalık Plan", Icons.Filled.DateRange, Icons.Outlined.DateRange)
    object History : Screen("history", "Geçmiş", Icons.Filled.History, Icons.Outlined.History)
    object Favorites : Screen("favorites", "Favoriler", Icons.Filled.Favorite, Icons.Outlined.FavoriteBorder)
    object Settings : Screen("settings", "Ayarlar", Icons.Filled.Settings, Icons.Outlined.Settings)

    // Sub-screens
    object Ingredients : Screen("ingredients", "Malzemeler", Icons.Filled.RestaurantMenu, Icons.Outlined.RestaurantMenu)
    object Categories : Screen("categories", "Kategoriler", Icons.Filled.RestaurantMenu, Icons.Outlined.RestaurantMenu)
    object RecipeDetail : Screen("recipe_detail/{recipeId}", "Tarif Detayı", Icons.Filled.RestaurantMenu, Icons.Outlined.RestaurantMenu) {
        fun createRoute(recipeId: String) = "recipe_detail/$recipeId"
    }
}

val bottomNavItems = listOf(
    Screen.Home,
    Screen.Shopping,
    Screen.Plan,
    Screen.History,
    Screen.Favorites,
    Screen.Settings
)

@Composable
fun BugunNeYesekApp(
    viewModel: RecipeViewModel = viewModel()
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val snackbarHostState = remember { SnackbarHostState() }
    val userMessage by viewModel.userMessage.collectAsStateWithLifecycle()

    LaunchedEffect(userMessage) {
        userMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearUserMessage()
        }
    }

    // Determine if bottom bar should be visible (hide on detail screen if desired, or keep everywhere)
    val showBottomBar = currentRoute in bottomNavItems.map { it.route }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.onSurface
                ) {
                    bottomNavItems.forEach { screen ->
                        val isSelected = currentRoute == screen.route
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = if (isSelected) screen.selectedIcon else screen.unselectedIcon,
                                    contentDescription = screen.title
                                )
                            },
                            label = {
                                Text(
                                    text = screen.title,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                indicatorColor = MaterialTheme.colorScheme.primaryContainer
                            ),
                            modifier = Modifier.testTag("nav_item_${screen.route}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    viewModel = viewModel,
                    onNavigateToIngredients = { navController.navigate(Screen.Ingredients.route) },
                    onNavigateToCategories = { navController.navigate(Screen.Categories.route) },
                    onOpenRecipeDetail = { recipe ->
                        navController.navigate(Screen.RecipeDetail.createRoute(recipe.id))
                    }
                )
            }

            composable(Screen.Ingredients.route) {
                IngredientSelectionScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onOpenRecipeDetail = { recipe ->
                        navController.navigate(Screen.RecipeDetail.createRoute(recipe.id))
                    }
                )
            }

            composable(Screen.Categories.route) {
                CategoryScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onOpenRecipeDetail = { recipe ->
                        navController.navigate(Screen.RecipeDetail.createRoute(recipe.id))
                    }
                )
            }

            composable(Screen.Shopping.route) {
                ShoppingListScreen(viewModel = viewModel)
            }

            composable(Screen.Plan.route) {
                WeeklyPlanScreen(
                    viewModel = viewModel,
                    onOpenRecipeDetail = { recipe ->
                        navController.navigate(Screen.RecipeDetail.createRoute(recipe.id))
                    }
                )
            }

            composable(Screen.History.route) {
                HistoryScreen(
                    viewModel = viewModel,
                    onOpenRecipeDetail = { recipe ->
                        navController.navigate(Screen.RecipeDetail.createRoute(recipe.id))
                    }
                )
            }

            composable(Screen.Favorites.route) {
                FavoritesScreen(
                    viewModel = viewModel,
                    onOpenRecipeDetail = { recipe ->
                        navController.navigate(Screen.RecipeDetail.createRoute(recipe.id))
                    }
                )
            }

            composable(Screen.Settings.route) {
                SettingsScreen(viewModel = viewModel)
            }

            composable(
                route = Screen.RecipeDetail.route,
                arguments = listOf(navArgument("recipeId") { type = NavType.StringType })
            ) { backStackEntry ->
                val recipeId = backStackEntry.arguments?.getString("recipeId") ?: ""
                val recipe = viewModel.repository.getRecipeById(recipeId)
                if (recipe != null) {
                    RecipeDetailScreen(
                        recipe = recipe,
                        viewModel = viewModel,
                        onBack = { navController.popBackStack() }
                    )
                }
            }
        }
    }
}
