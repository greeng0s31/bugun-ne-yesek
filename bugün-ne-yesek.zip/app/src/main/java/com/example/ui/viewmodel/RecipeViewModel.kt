package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.TurkishRecipesData
import com.example.data.local.entity.FavoriteEntity
import com.example.data.local.entity.MealHistoryEntity
import com.example.data.local.entity.ShoppingItemEntity
import com.example.data.local.entity.UserSettingsEntity
import com.example.data.local.entity.WeeklyPlanEntity
import com.example.data.model.RecipeItem
import com.example.data.repository.AppRepository
import com.example.data.repository.RecipeMatchResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class RecipeViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    val repository = AppRepository(
        favoriteDao = db.favoriteDao(),
        mealHistoryDao = db.mealHistoryDao(),
        shoppingDao = db.shoppingDao(),
        weeklyPlanDao = db.weeklyPlanDao(),
        settingsDao = db.settingsDao()
    )

    // User Settings
    val settings: StateFlow<UserSettingsEntity?> = repository.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = UserSettingsEntity(id = 1, defaultServings = 4, dietPreference = "Normal", excludedIngredientsCsv = "")
    )

    // Favorites
    val favorites: StateFlow<List<FavoriteEntity>> = repository.favoritesFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // History
    val history: StateFlow<List<MealHistoryEntity>> = repository.historyFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Shopping List
    val shoppingItems: StateFlow<List<ShoppingItemEntity>> = repository.shoppingItemsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Weekly Plan
    val weeklyPlan: StateFlow<List<WeeklyPlanEntity>> = repository.weeklyPlanFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Quick Suggestion Dialog State
    private val _suggestedRecipe = MutableStateFlow<RecipeItem?>(null)
    val suggestedRecipe: StateFlow<RecipeItem?> = _suggestedRecipe.asStateFlow()

    private val _suggestedCountLast7Days = MutableStateFlow(0)
    val suggestedCountLast7Days: StateFlow<Int> = _suggestedCountLast7Days.asStateFlow()

    private val _showSuggestionDialog = MutableStateFlow(false)
    val showSuggestionDialog: StateFlow<Boolean> = _showSuggestionDialog.asStateFlow()

    // Ingredient Selection Screen State
    private val _selectedIngredients = MutableStateFlow<Set<String>>(emptySet())
    val selectedIngredients: StateFlow<Set<String>> = _selectedIngredients.asStateFlow()

    private val _timeFilter = MutableStateFlow<Int?>(null) // null = Hepsi, 15, 30, 60
    val timeFilter: StateFlow<Int?> = _timeFilter.asStateFlow()

    private val _dietFilter = MutableStateFlow<String?>(null) // null, "Vejetaryen", "Etsiz", "Hafif-Diyet"
    val dietFilter: StateFlow<String?> = _dietFilter.asStateFlow()

    private val _mealTypeFilter = MutableStateFlow<String?>(null) // null, "Kahvaltı", "Öğle", "Akşam", "Atıştırmalık"
    val mealTypeFilter: StateFlow<String?> = _mealTypeFilter.asStateFlow()

    private val _matchingRecipes = MutableStateFlow<List<RecipeMatchResult>>(emptyList())
    val matchingRecipes: StateFlow<List<RecipeMatchResult>> = _matchingRecipes.asStateFlow()

    // Category Screen State
    private val _selectedCategory = MutableStateFlow("Tümü")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    // Active Recipe Detail Servings
    private val _detailServings = MutableStateFlow(4)
    val detailServings: StateFlow<Int> = _detailServings.asStateFlow()

    // Notification / Toast Message banner
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    init {
        // Load initial suggestion
        viewModelScope.launch {
            val rec = repository.getAllRecipes().firstOrNull()
            _suggestedRecipe.value = rec
        }
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    fun triggerQuickSuggestion(category: String? = null) {
        viewModelScope.launch {
            val userSet = settings.value
            val (rec, count) = repository.getSmartRecommendation(
                category = category,
                userSettings = userSet
            )
            _suggestedRecipe.value = rec
            _suggestedCountLast7Days.value = count
            _showSuggestionDialog.value = true
        }
    }

    fun dismissSuggestionDialog() {
        _showSuggestionDialog.value = false
    }

    // --- INGREDIENT SELECTION ---
    fun toggleIngredient(ingredient: String) {
        val current = _selectedIngredients.value.toMutableSet()
        if (current.contains(ingredient)) {
            current.remove(ingredient)
        } else {
            current.add(ingredient)
        }
        _selectedIngredients.value = current
        recalculateIngredientMatches()
    }

    fun clearSelectedIngredients() {
        _selectedIngredients.value = emptySet()
        _matchingRecipes.value = emptyList()
    }

    fun setTimeFilter(minutes: Int?) {
        _timeFilter.value = if (_timeFilter.value == minutes) null else minutes
        recalculateIngredientMatches()
    }

    fun setDietFilter(diet: String?) {
        _dietFilter.value = if (_dietFilter.value == diet) null else diet
        recalculateIngredientMatches()
    }

    fun setMealTypeFilter(mealType: String?) {
        _mealTypeFilter.value = if (_mealTypeFilter.value == mealType) null else mealType
        recalculateIngredientMatches()
    }

    private fun recalculateIngredientMatches() {
        val selected = _selectedIngredients.value
        if (selected.isEmpty()) {
            _matchingRecipes.value = emptyList()
            return
        }
        val userSet = settings.value
        val matches = repository.findRecipesByIngredients(
            selectedIngredients = selected,
            userSettings = userSet,
            maxTimeMinutes = _timeFilter.value,
            dietFilter = _dietFilter.value
        )
        // Additional filter by mealType if set
        val filtered = if (_mealTypeFilter.value != null) {
            matches.filter { it.recipe.mealType == _mealTypeFilter.value }
        } else matches

        _matchingRecipes.value = filtered
    }

    // --- CATEGORY BROWSING ---
    fun selectCategory(cat: String) {
        _selectedCategory.value = cat
    }

    // --- RECIPE DETAIL & PORTION ---
    fun setDetailServings(servings: Int) {
        _detailServings.value = servings.coerceIn(1, 16)
    }

    fun incrementDetailServings() {
        _detailServings.value = (_detailServings.value + 1).coerceAtMost(16)
    }

    fun decrementDetailServings() {
        _detailServings.value = (_detailServings.value - 1).coerceAtLeast(1)
    }

    fun isRecipeFavorite(recipeId: String): Boolean {
        return favorites.value.any { it.recipeId == recipeId }
    }

    fun toggleFavorite(recipeId: String) {
        viewModelScope.launch {
            repository.toggleFavorite(recipeId)
            val isNowFav = repository.isFavoriteFlow(recipeId)
            _userMessage.value = "Favoriler güncellendi"
        }
    }

    fun markMealAsCooked(recipe: RecipeItem, servings: Int) {
        viewModelScope.launch {
            repository.recordMealCooked(
                recipeId = recipe.id,
                recipeTitle = recipe.title,
                servings = servings,
                emoji = recipe.emoji,
                note = "Afiyet olsun!"
            )
            _userMessage.value = "Ellerinize sağlık! Yemek geçmişe eklendi."
        }
    }

    suspend fun getCookCountInLast7Days(recipeId: String): Int {
        return repository.getCookCountInLast7Days(recipeId)
    }

    // --- SHOPPING LIST ---
    fun addMissingIngredients(recipe: RecipeItem, missing: List<String>, servings: Int) {
        viewModelScope.launch {
            repository.addMissingIngredientsToShoppingList(recipe, missing, servings)
            _userMessage.value = "${missing.size} eksik malzeme alışveriş listenize eklendi"
        }
    }

    fun addCustomShoppingItem(name: String, amount: String) {
        viewModelScope.launch {
            repository.addShoppingItem(name, amount)
        }
    }

    fun toggleShoppingItem(id: Long, isChecked: Boolean) {
        viewModelScope.launch {
            repository.toggleShoppingItemChecked(id, isChecked)
        }
    }

    fun deleteShoppingItem(id: Long) {
        viewModelScope.launch {
            repository.deleteShoppingItem(id)
        }
    }

    fun deleteCheckedShoppingItems() {
        viewModelScope.launch {
            repository.deleteCheckedShoppingItems()
            _userMessage.value = "Alınan malzemeler temizlendi"
        }
    }

    fun clearAllShoppingItems() {
        viewModelScope.launch {
            repository.clearAllShoppingItems()
        }
    }

    // --- WEEKLY PLAN ---
    fun setPlanDayRecipe(dayIndex: Int, dayName: String, recipe: RecipeItem) {
        viewModelScope.launch {
            repository.setWeeklyPlanDay(dayIndex, dayName, recipe)
            _userMessage.value = "$dayName için ${recipe.title} planlandı"
        }
    }

    fun clearPlanDay(dayIndex: Int) {
        viewModelScope.launch {
            repository.clearWeeklyPlanDay(dayIndex)
        }
    }

    fun autoSuggestDayMeal(dayIndex: Int, dayName: String) {
        viewModelScope.launch {
            val (rec, _) = repository.getSmartRecommendation(userSettings = settings.value)
            repository.setWeeklyPlanDay(dayIndex, dayName, rec)
            _userMessage.value = "$dayName için ${rec.title} önerildi"
        }
    }

    fun addWeeklyPlanIngredientsToShoppingList() {
        viewModelScope.launch {
            val plan = weeklyPlan.value
            var addedCount = 0
            val currentServings = settings.value?.defaultServings ?: 4

            plan.forEach { day ->
                day.recipeId?.let { rId ->
                    val recipe = repository.getRecipeById(rId)
                    recipe?.let { r ->
                        r.ingredients.forEach { ing ->
                            val scaled = ing.getScaledAmount(currentServings)
                            repository.addShoppingItem(
                                name = ing.name,
                                amount = scaled,
                                recipeTitle = "${day.dayName}: ${r.title}"
                            )
                            addedCount++
                        }
                    }
                }
            }
            _userMessage.value = if (addedCount > 0) {
                "Haftalık plandaki tüm malzemeler ($addedCount adet) alışveriş listesine eklendi"
            } else {
                "Haftalık planda henüz yemek seçilmemiş"
            }
        }
    }

    // --- SETTINGS ---
    fun updateHouseholdSize(size: Int) {
        viewModelScope.launch {
            val current = settings.value ?: UserSettingsEntity()
            val updated = current.copy(defaultServings = size.coerceIn(1, 12))
            repository.saveSettings(updated)
            _detailServings.value = updated.defaultServings
        }
    }

    fun updateDietPreference(diet: String) {
        viewModelScope.launch {
            val current = settings.value ?: UserSettingsEntity()
            val updated = current.copy(dietPreference = diet)
            repository.saveSettings(updated)
        }
    }

    fun updateExcludedIngredients(excludedCsv: String) {
        viewModelScope.launch {
            val current = settings.value ?: UserSettingsEntity()
            val updated = current.copy(excludedIngredientsCsv = excludedCsv)
            repository.saveSettings(updated)
        }
    }

    fun deleteHistoryItem(id: Long) {
        viewModelScope.launch {
            repository.deleteHistoryMeal(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearHistory()
            _userMessage.value = "Yemek geçmişi temizlendi"
        }
    }
}
