package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = WarmTerracotta,
    onPrimary = Color.White,
    primaryContainer = WarmTerracottaContainer,
    onPrimaryContainer = OnWarmTerracottaContainer,
    secondary = SaffronAmber,
    onSecondary = Color.White,
    secondaryContainer = SaffronAmberContainer,
    onSecondaryContainer = OnSaffronAmberContainer,
    tertiary = HerbOlive,
    onTertiary = Color.White,
    tertiaryContainer = HerbOliveContainer,
    onTertiaryContainer = OnHerbOliveContainer,
    background = CreamBackground,
    onBackground = WarmTextDark,
    surface = CreamSurface,
    onSurface = WarmTextDark,
    surfaceVariant = CreamSurfaceVariant,
    onSurfaceVariant = WarmTextMedium,
    surfaceContainer = CreamSurfaceContainer,
    surfaceContainerHigh = CreamSurfaceContainerHigh,
    outline = WarmOutline
)

private val DarkColorScheme = darkColorScheme(
    primary = WarmTerracottaLight,
    onPrimary = OnWarmTerracottaContainer,
    primaryContainer = WarmTerracottaDark,
    onPrimaryContainer = WarmTerracottaContainer,
    secondary = SaffronAmberLight,
    onSecondary = OnSaffronAmberContainer,
    secondaryContainer = SaffronAmber,
    onSecondaryContainer = Color.White,
    tertiary = HerbOliveContainer,
    onTertiary = OnHerbOliveContainer,
    background = DarkEspressoBackground,
    onBackground = DarkWarmText,
    surface = DarkMahoganySurface,
    onSurface = DarkWarmText,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkWarmTextSecondary,
    surfaceContainer = DarkSurfaceContainer,
    outline = DarkOutline
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // Stick to custom warm appetizing culinary palette for both light and dark modes
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
