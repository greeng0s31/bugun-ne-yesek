package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Warm appetizing home-cooked culinary palette (Terracotta, Amber, Warm Beige/Cream)
val WarmTerracotta = Color(0xFFC83818)
val WarmTerracottaDark = Color(0xFF96240A)
val WarmTerracottaLight = Color(0xFFFF8B70)
val WarmTerracottaContainer = Color(0xFFFFDDD4)
val OnWarmTerracottaContainer = Color(0xFF410002)

val SaffronAmber = Color(0xFFE65100)
val SaffronAmberLight = Color(0xFFFFB74D)
val SaffronAmberContainer = Color(0xFFFFE8D1)
val OnSaffronAmberContainer = Color(0xFF331400)

val HerbOlive = Color(0xFF386B26)
val HerbOliveContainer = Color(0xFFD6F0C2)
val OnHerbOliveContainer = Color(0xFF072100)

val CreamBackground = Color(0xFFFDF8F3)
val CreamSurface = Color(0xFFFFFBF7)
val CreamSurfaceVariant = Color(0xFFF4ECE4)
val CreamSurfaceContainer = Color(0xFFF7EFE7)
val CreamSurfaceContainerHigh = Color(0xFFF0E5DC)
val WarmTextDark = Color(0xFF27211E)
val WarmTextMedium = Color(0xFF5C524C)
val WarmOutline = Color(0xFFD8CCC2)

// Dark Theme Variants
val DarkEspressoBackground = Color(0xFF191311)
val DarkMahoganySurface = Color(0xFF231B18)
val DarkSurfaceVariant = Color(0xFF332924)
val DarkSurfaceContainer = Color(0xFF2C221F)
val DarkWarmText = Color(0xFFF5EEE9)
val DarkWarmTextSecondary = Color(0xFFC9BCB4)
val DarkOutline = Color(0xFF5A4D46)
