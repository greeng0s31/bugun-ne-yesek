package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.FavoriteEntity
import com.example.data.local.entity.MealHistoryEntity
import com.example.data.local.entity.ShoppingItemEntity
import com.example.data.local.entity.UserSettingsEntity
import com.example.data.local.entity.WeeklyPlanEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FavoriteDao {
    @Query("SELECT * FROM favorites ORDER BY savedAtTimestamp DESC")
    fun getAllFavorites(): Flow<List<FavoriteEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE recipeId = :recipeId)")
    fun isFavorite(recipeId: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addFavorite(favorite: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE recipeId = :recipeId")
    suspend fun removeFavorite(recipeId: String)
}

@Dao
interface MealHistoryDao {
    @Query("SELECT * FROM meal_history ORDER BY cookedTimestamp DESC")
    fun getAllHistory(): Flow<List<MealHistoryEntity>>

    @Query("SELECT * FROM meal_history WHERE cookedTimestamp >= :sinceTimestamp ORDER BY cookedTimestamp DESC")
    fun getRecentHistory(sinceTimestamp: Long): Flow<List<MealHistoryEntity>>

    @Query("SELECT COUNT(*) FROM meal_history WHERE recipeId = :recipeId AND cookedTimestamp >= :sinceTimestamp")
    suspend fun getCookCountInLastDays(recipeId: String, sinceTimestamp: Long): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMeal(meal: MealHistoryEntity)

    @Query("DELETE FROM meal_history WHERE id = :id")
    suspend fun deleteMeal(id: Long)

    @Query("DELETE FROM meal_history")
    suspend fun clearHistory()
}

@Dao
interface ShoppingDao {
    @Query("SELECT * FROM shopping_items ORDER BY isChecked ASC, id DESC")
    fun getAllShoppingItems(): Flow<List<ShoppingItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: ShoppingItemEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<ShoppingItemEntity>)

    @Query("UPDATE shopping_items SET isChecked = :isChecked WHERE id = :id")
    suspend fun setChecked(id: Long, isChecked: Boolean)

    @Query("DELETE FROM shopping_items WHERE id = :id")
    suspend fun deleteItem(id: Long)

    @Query("DELETE FROM shopping_items WHERE isChecked = 1")
    suspend fun deleteCheckedItems()

    @Query("DELETE FROM shopping_items")
    suspend fun clearAll()
}

@Dao
interface WeeklyPlanDao {
    @Query("SELECT * FROM weekly_plan ORDER BY dayIndex ASC")
    fun getWeeklyPlan(): Flow<List<WeeklyPlanEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateDay(day: WeeklyPlanEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(days: List<WeeklyPlanEntity>)

    @Query("UPDATE weekly_plan SET recipeId = NULL, recipeTitle = NULL, emoji = NULL WHERE dayIndex = :dayIndex")
    suspend fun clearDay(dayIndex: Int)
}

@Dao
interface SettingsDao {
    @Query("SELECT * FROM user_settings WHERE id = 1")
    fun getSettings(): Flow<UserSettingsEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSettings(settings: UserSettingsEntity)
}
