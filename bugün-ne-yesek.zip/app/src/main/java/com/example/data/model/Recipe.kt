package com.example.data.model

data class RecipeIngredient(
    val name: String,
    val amountPerServing: Double,
    val unit: String,
    val isMain: Boolean = false
) {
    fun getScaledAmount(servings: Int): String {
        val total = amountPerServing * servings
        return when {
            total == 0.0 -> ""
            total == total.toInt().toDouble() -> "${total.toInt()} $unit".trim()
            total < 1.0 && (total * 2) == (total * 2).toInt().toDouble() -> "1/2 $unit".trim()
            else -> String.format(java.util.Locale.US, "%.1f %s", total, unit).trim()
        }
    }
}

data class RecipeStep(
    val stepNumber: Int,
    val instruction: String,
    val durationMinutes: Int = 0
)

data class RecipeItem(
    val id: String,
    val title: String,
    val description: String,
    val category: String,
    val mealType: String,
    val dietType: String,
    val prepTimeMinutes: Int,
    val cookTimeMinutes: Int,
    val difficulty: String,
    val baseServings: Int = 4,
    val ingredients: List<RecipeIngredient>,
    val instructions: List<RecipeStep>,
    val tips: String,
    val emoji: String,
    val caloriesApprox: Int = 350
) {
    val totalTimeMinutes: Int get() = prepTimeMinutes + cookTimeMinutes
}
