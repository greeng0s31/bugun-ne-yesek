package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.FavoriteDao
import com.example.data.local.dao.MealHistoryDao
import com.example.data.local.dao.SettingsDao
import com.example.data.local.dao.ShoppingDao
import com.example.data.local.dao.WeeklyPlanDao
import com.example.data.local.entity.FavoriteEntity
import com.example.data.local.entity.MealHistoryEntity
import com.example.data.local.entity.ShoppingItemEntity
import com.example.data.local.entity.UserSettingsEntity
import com.example.data.local.entity.WeeklyPlanEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        FavoriteEntity::class,
        MealHistoryEntity::class,
        ShoppingItemEntity::class,
        WeeklyPlanEntity::class,
        UserSettingsEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun favoriteDao(): FavoriteDao
    abstract fun mealHistoryDao(): MealHistoryDao
    abstract fun shoppingDao(): ShoppingDao
    abstract fun weeklyPlanDao(): WeeklyPlanDao
    abstract fun settingsDao(): SettingsDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "bugun_ne_yesek_database"
                ).addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Seed default weekly days and default settings
                        CoroutineScope(Dispatchers.IO).launch {
                            val database = getInstance(context)
                            val days = listOf(
                                WeeklyPlanEntity(1, "Pazartesi", null, null, null, "Akşam Yemeği"),
                                WeeklyPlanEntity(2, "Salı", null, null, null, "Akşam Yemeği"),
                                WeeklyPlanEntity(3, "Çarşamba", null, null, null, "Akşam Yemeği"),
                                WeeklyPlanEntity(4, "Perşembe", null, null, null, "Akşam Yemeği"),
                                WeeklyPlanEntity(5, "Cuma", null, null, null, "Akşam Yemeği"),
                                WeeklyPlanEntity(6, "Cumartesi", null, null, null, "Akşam Yemeği"),
                                WeeklyPlanEntity(7, "Pazar", null, null, null, "Akşam Yemeği")
                            )
                            database.weeklyPlanDao().insertAll(days)
                            database.settingsDao().saveSettings(
                                UserSettingsEntity(
                                    id = 1,
                                    defaultServings = 4,
                                    dietPreference = "Normal",
                                    excludedIngredientsCsv = ""
                                )
                            )
                        }
                    }
                }).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
