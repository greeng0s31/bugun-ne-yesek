package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val recipeId: String,
    val savedAtTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "meal_history")
data class MealHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val recipeId: String,
    val recipeTitle: String,
    val cookedTimestamp: Long = System.currentTimeMillis(),
    val servings: Int = 4,
    val emoji: String = "🍲",
    val note: String = ""
)

@Entity(tableName = "shopping_items")
data class ShoppingItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ingredientName: String,
    val amount: String = "",
    val isChecked: Boolean = false,
    val recipeTitle: String = ""
)

@Entity(tableName = "weekly_plan")
data class WeeklyPlanEntity(
    @PrimaryKey val dayIndex: Int, // 1 = Pazartesi, 2 = Salı, ..., 7 = Pazar
    val dayName: String,
    val recipeId: String? = null,
    val recipeTitle: String? = null,
    val emoji: String? = null,
    val mealType: String = "Akşam Yemeği"
)

@Entity(tableName = "user_settings")
data class UserSettingsEntity(
    @PrimaryKey val id: Int = 1,
    val defaultServings: Int = 4,
    val dietPreference: String = "Normal", // "Normal", "Vejetaryen", "Vegan"
    val excludedIngredientsCsv: String = "" // e.g. "Mantar, Patlıcan, Deniz Ürünü"
)
