package com.example.data.repository

import com.example.data.local.TurkishRecipesData
import com.example.data.local.dao.FavoriteDao
import com.example.data.local.dao.MealHistoryDao
import com.example.data.local.dao.SettingsDao
import com.example.data.local.dao.ShoppingDao
import com.example.data.local.dao.WeeklyPlanDao
import com.example.data.local.entity.FavoriteEntity
import com.example.data.local.entity.MealHistoryEntity
import com.example.data.local.entity.ShoppingItemEntity
import com.example.data.local.entity.UserSettingsEntity
import com.example.data.local.entity.WeeklyPlanEntity
import com.example.data.model.RecipeItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import java.util.Locale
import kotlin.random.Random

data class RecipeMatchResult(
    val recipe: RecipeItem,
    val matchedIngredients: List<String>,
    val missingIngredients: List<String>,
    val matchPercentage: Int
)

class AppRepository(
    private val favoriteDao: FavoriteDao,
    private val mealHistoryDao: MealHistoryDao,
    private val shoppingDao: ShoppingDao,
    private val weeklyPlanDao: WeeklyPlanDao,
    private val settingsDao: SettingsDao
) {

    // --- SETTINGS ---
    val settingsFlow: Flow<UserSettingsEntity?> = settingsDao.getSettings()

    suspend fun saveSettings(settings: UserSettingsEntity) {
        settingsDao.saveSettings(settings)
    }

    // --- FAVORITES ---
    val favoritesFlow: Flow<List<FavoriteEntity>> = favoriteDao.getAllFavorites()

    fun isFavoriteFlow(recipeId: String): Flow<Boolean> = favoriteDao.isFavorite(recipeId)

    suspend fun toggleFavorite(recipeId: String) {
        val currentFavs = favoriteDao.getAllFavorites().firstOrNull() ?: emptyList()
        val isFav = currentFavs.any { it.recipeId == recipeId }
        if (isFav) {
            favoriteDao.removeFavorite(recipeId)
        } else {
            favoriteDao.addFavorite(FavoriteEntity(recipeId))
        }
    }

    // --- MEAL HISTORY ---
    val historyFlow: Flow<List<MealHistoryEntity>> = mealHistoryDao.getAllHistory()

    suspend fun recordMealCooked(recipeId: String, recipeTitle: String, servings: Int, emoji: String, note: String = "") {
        mealHistoryDao.insertMeal(
            MealHistoryEntity(
                recipeId = recipeId,
                recipeTitle = recipeTitle,
                cookedTimestamp = System.currentTimeMillis(),
                servings = servings,
                emoji = emoji,
                note = note
            )
        )
    }

    suspend fun getCookCountInLast7Days(recipeId: String): Int {
        val sevenDaysAgo = System.currentTimeMillis() - (7L * 24 * 60 * 60 * 1000)
        return mealHistoryDao.getCookCountInLastDays(recipeId, sevenDaysAgo)
    }

    suspend fun deleteHistoryMeal(id: Long) {
        mealHistoryDao.deleteMeal(id)
    }

    suspend fun clearHistory() {
        mealHistoryDao.clearHistory()
    }

    // --- SHOPPING LIST ---
    val shoppingItemsFlow: Flow<List<ShoppingItemEntity>> = shoppingDao.getAllShoppingItems()

    suspend fun addShoppingItem(name: String, amount: String, recipeTitle: String = "") {
        if (name.isNotBlank()) {
            shoppingDao.insertItem(
                ShoppingItemEntity(
                    ingredientName = name.trim(),
                    amount = amount.trim(),
                    isChecked = false,
                    recipeTitle = recipeTitle
                )
            )
        }
    }

    suspend fun addMissingIngredientsToShoppingList(recipe: RecipeItem, missingIngredients: List<String>, servings: Int) {
        val items = missingIngredients.mapNotNull { missingName ->
            val ing = recipe.ingredients.find {
                it.name.contains(missingName, ignoreCase = true) || missingName.contains(it.name, ignoreCase = true)
            }
            val amountStr = ing?.getScaledAmount(servings) ?: ""
            ShoppingItemEntity(
                ingredientName = missingName,
                amount = amountStr,
                isChecked = false,
                recipeTitle = recipe.title
            )
        }
        shoppingDao.insertAll(items)
    }

    suspend fun toggleShoppingItemChecked(id: Long, isChecked: Boolean) {
        shoppingDao.setChecked(id, isChecked)
    }

    suspend fun deleteShoppingItem(id: Long) {
        shoppingDao.deleteItem(id)
    }

    suspend fun deleteCheckedShoppingItems() {
        shoppingDao.deleteCheckedItems()
    }

    suspend fun clearAllShoppingItems() {
        shoppingDao.clearAll()
    }

    // --- WEEKLY PLAN ---
    val weeklyPlanFlow: Flow<List<WeeklyPlanEntity>> = weeklyPlanDao.getWeeklyPlan()

    suspend fun setWeeklyPlanDay(dayIndex: Int, dayName: String, recipe: RecipeItem, mealType: String = "Akşam Yemeği") {
        weeklyPlanDao.insertOrUpdateDay(
            WeeklyPlanEntity(
                dayIndex = dayIndex,
                dayName = dayName,
                recipeId = recipe.id,
                recipeTitle = recipe.title,
                emoji = recipe.emoji,
                mealType = mealType
            )
        )
    }

    suspend fun clearWeeklyPlanDay(dayIndex: Int) {
        weeklyPlanDao.clearDay(dayIndex)
    }

    // --- RECIPES FILTERING & RECOMMENDATION ENGINE ---
    fun getAllRecipes(): List<RecipeItem> = TurkishRecipesData.allRecipes

    fun getRecipeById(id: String): RecipeItem? = TurkishRecipesData.getRecipeById(id)

    /**
     * Smart recommendation:
     * - Respects diet preference (Vegetarian, Vegan)
     * - Filters out excluded/allergic ingredients
     * - Discourages recently cooked meals in past 7 days
     */
    suspend fun getSmartRecommendation(
        category: String? = null,
        dietFilter: String? = null,
        maxTimeMinutes: Int? = null,
        userSettings: UserSettingsEntity? = null
    ): Pair<RecipeItem, Int> { // Returns (Recipe, countCookedInPast7Days)
        val sevenDaysAgo = System.currentTimeMillis() - (7L * 24 * 60 * 60 * 1000)

        val excluded = userSettings?.excludedIngredientsCsv
            ?.split(",")
            ?.map { it.trim().lowercase(Locale("tr")) }
            ?.filter { it.isNotBlank() }
            ?: emptyList()

        val diet = dietFilter ?: userSettings?.dietPreference ?: "Normal"

        var eligible = TurkishRecipesData.allRecipes.filter { recipe ->
            // Excluded ingredients filter
            val hasExcluded = excluded.any { ex ->
                recipe.ingredients.any { it.name.lowercase(Locale("tr")).contains(ex) }
            }
            if (hasExcluded) return@filter false

            // Diet filter
            if (diet == "Vejetaryen" && recipe.dietType != "Vejetaryen" && recipe.dietType != "Vegan" && recipe.dietType != "Etsiz") {
                return@filter false
            }
            if (diet == "Vegan" && recipe.dietType != "Vegan") {
                return@filter false
            }
            if (diet == "Hafif-Diyet" && recipe.category != "Hafif & Diyet" && recipe.category != "Çorba") {
                // soft filter
            }

            // Category filter
            if (category != null && category != "Tümü" && recipe.category != category) {
                return@filter false
            }

            // Time filter
            if (maxTimeMinutes != null && recipe.totalTimeMinutes > maxTimeMinutes) {
                return@filter false
            }

            true
        }

        if (eligible.isEmpty()) {
            eligible = TurkishRecipesData.allRecipes
        }

        // Check recent history to avoid repeating recent recipes
        val recipesWithCounts = eligible.map { recipe ->
            val count = mealHistoryDao.getCookCountInLastDays(recipe.id, sevenDaysAgo)
            Pair(recipe, count)
        }

        // Prefer recipes cooked 0 times in past 7 days
        val unmadeRecently = recipesWithCounts.filter { it.second == 0 }
        val candidate = if (unmadeRecently.isNotEmpty()) {
            unmadeRecently.random(Random)
        } else {
            // Pick least frequently made
            recipesWithCounts.minByOrNull { it.second } ?: (eligible.random(Random) to 0)
        }

        return candidate
    }

    /**
     * "Malzemelerime Göre Öner" engine:
     * Takes a list of user-selected ingredients (e.g. ["Tavuk", "Patates", "Soğan"])
     * Calculates match scores and missing ingredients for recipes.
     * Returns top 3-5 practical recipes.
     */
    fun findRecipesByIngredients(
        selectedIngredients: Set<String>,
        userSettings: UserSettingsEntity? = null,
        categoryFilter: String? = null,
        maxTimeMinutes: Int? = null,
        dietFilter: String? = null
    ): List<RecipeMatchResult> {
        if (selectedIngredients.isEmpty()) return emptyList()

        val excluded = userSettings?.excludedIngredientsCsv
            ?.split(",")
            ?.map { it.trim().lowercase(Locale("tr")) }
            ?.filter { it.isNotBlank() }
            ?: emptyList()

        val normalizedSelected = selectedIngredients.map { it.lowercase(Locale("tr")).trim() }

        val results = TurkishRecipesData.allRecipes.mapNotNull { recipe ->
            // Check allergen exclusion
            val hasExcluded = excluded.any { ex ->
                recipe.ingredients.any { it.name.lowercase(Locale("tr")).contains(ex) }
            }
            if (hasExcluded) return@mapNotNull null

            // Check diet filter
            val diet = dietFilter ?: userSettings?.dietPreference ?: "Normal"
            if (diet == "Vejetaryen" && recipe.dietType != "Vejetaryen" && recipe.dietType != "Vegan" && recipe.dietType != "Etsiz") {
                return@mapNotNull null
            }
            if (diet == "Vegan" && recipe.dietType != "Vegan") {
                return@mapNotNull null
            }

            // Category filter
            if (categoryFilter != null && categoryFilter != "Tümü" && recipe.category != categoryFilter) {
                return@mapNotNull null
            }

            // Time filter
            if (maxTimeMinutes != null && recipe.totalTimeMinutes > maxTimeMinutes) {
                return@mapNotNull null
            }

            // Match ingredients
            val matched = mutableListOf<String>()
            val missing = mutableListOf<String>()

            for (ing in recipe.ingredients) {
                val ingNameLower = ing.name.lowercase(Locale("tr"))
                val isMatched = normalizedSelected.any { sel ->
                    ingNameLower.contains(sel) || sel.contains(ingNameLower)
                }
                if (isMatched) {
                    matched.add(ing.name)
                } else {
                    // Only count key ingredients as missing, skip trivial salt/spices/water
                    if (!ingNameLower.contains("tuz") && !ingNameLower.contains("su") && !ingNameLower.contains("karabiber")) {
                        missing.add(ing.name)
                    }
                }
            }

            // At least 1 main ingredient must match
            if (matched.isEmpty()) return@mapNotNull null

            val totalKeyIngredients = matched.size + missing.size
            val matchPercentage = if (totalKeyIngredients > 0) {
                ((matched.size.toDouble() / totalKeyIngredients.toDouble()) * 100).toInt()
            } else 0

            RecipeMatchResult(
                recipe = recipe,
                matchedIngredients = matched,
                missingIngredients = missing,
                matchPercentage = matchPercentage
            )
        }

        // Sort by match percentage descending, then missing count ascending
        return results.sortedWith(
            compareByDescending<RecipeMatchResult> { it.matchedIngredients.size }
                .thenBy { it.missingIngredients.size }
        ).take(5)
    }
}
