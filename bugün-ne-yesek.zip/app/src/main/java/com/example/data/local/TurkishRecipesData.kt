package com.example.data.local

import com.example.data.model.RecipeIngredient
import com.example.data.model.RecipeItem
import com.example.data.model.RecipeStep

object TurkishRecipesData {

    val allRecipes: List<RecipeItem> = listOf(
        RecipeItem(
            id = "rec_mercimek_corbasi",
            title = "Kırmızı Mercimek Çorbası",
            description = "Geleneksel, içinizi ısıtan, limon ve tereyağlı nane sosuyla nefis lokanta usulü mercimek çorbası.",
            category = "Çorba",
            mealType = "Akşam",
            dietType = "Vejetaryen",
            prepTimeMinutes = 10,
            cookTimeMinutes = 20,
            difficulty = "Kolay",
            baseServings = 4,
            emoji = "🥣",
            caloriesApprox = 180,
            tips = "Pişirdikten sonra üzerine kızdırılmış tereyağı, nane ve pul biber gezdirip limon sıkarak servis edin.",
            ingredients = listOf(
                RecipeIngredient("Kırmızı mercimek", 0.25, "su bardağı", isMain = true),
                RecipeIngredient("Soğan", 0.25, "adet", isMain = true),
                RecipeIngredient("Havuç", 0.25, "adet"),
                RecipeIngredient("Patates", 0.25, "adet"),
                RecipeIngredient("Tereyağı", 0.5, "yemek kaşığı"),
                RecipeIngredient("Salça", 0.25, "tatlı kaşığı"),
                RecipeIngredient("Tuz & Nane", 0.25, "tatlı kaşığı")
            ),
            instructions = listOf(
                RecipeStep(1, "Soğan, havuç ve patatesi iri küpler halinde doğrayın.", 5),
                RecipeStep(2, "Tencerede tereyağını eritip sebzeleri 3-4 dakika kavurun.", 4),
                RecipeStep(3, "Yıkanmış kırmızı mercimeği ve 5 su bardağı sıcak suyu ekleyin. Kaynamaya bırakın.", 15),
                RecipeStep(4, "Mercimekler ve sebzeler yumuşayınca blenderdan geçirip pürüzsüz kıvama getirin.", 2),
                RecipeStep(5, "Ayrı küçük tavada tereyağında nane ve pul biberi kızdırıp çorbaya ekleyin.", 3)
            )
        ),
        RecipeItem(
            id = "rec_yayla_corbasi",
            title = "Yayla Çorbası",
            description = "Nane kokulu, ferahlatıcı ve besleyici klasik yoğurtlu Türk yayla çorbası.",
            category = "Çorba",
            mealType = "Akşam",
            dietType = "Vejetaryen",
            prepTimeMinutes = 10,
            cookTimeMinutes = 15,
            difficulty = "Kolay",
            baseServings = 4,
            emoji = "🍲",
            caloriesApprox = 160,
            tips = "Yoğurt sosunu eklerken kesilmemesi için çorbanın suyundan 1 kepçe alıp sosa yavaşça ilave ederek ılıtın.",
            ingredients = listOf(
                RecipeIngredient("Pirinç", 0.15, "çay bardağı", isMain = true),
                RecipeIngredient("Yoğurt", 0.35, "su bardağı", isMain = true),
                RecipeIngredient("Yumurta", 0.25, "adet"),
                RecipeIngredient("Un", 0.25, "yemek kaşığı"),
                RecipeIngredient("Tereyağı", 0.5, "yemek kaşığı"),
                RecipeIngredient("Nane", 0.25, "tatlı kaşığı")
            ),
            instructions = listOf(
                RecipeStep(1, "Pirinci tencerede 4 su bardağı su ile yumuşayana kadar haşlayın.", 10),
                RecipeStep(2, "Bir kasede yoğurt, yumurta sarısı ve unu pürüzsüzce çırpın.", 3),
                RecipeStep(3, "Tenceredeki sıcak sudan alıp yoğurtlu karışıma azar azar dökerek ılıtın.", 2),
                RecipeStep(4, "Ilıyan karışımı tencereye sürekli karıştırarak ekleyin ve bir taşım kaynatın.", 5),
                RecipeStep(5, "Tereyağında kızdırılmış kuru naneyi üzerine döküp servis edin.", 2)
            )
        ),
        RecipeItem(
            id = "rec_tarhana_corbasi",
            title = "Ev Yapımı Tarhana Çorbası",
            description = "Bol sarımsak ve tereyağlı, kış aylarının vazgeçilmezi şifalı tarhana çorbası.",
            category = "Çorba",
            mealType = "Akşam",
            dietType = "Vejetaryen",
            prepTimeMinutes = 5,
            cookTimeMinutes = 10,
            difficulty = "Kolay",
            baseServings = 4,
            emoji = "🥣",
            caloriesApprox = 140,
            tips = "Topaklanmaması için tarhanayı ilk başta soğuk su ile açın, ocakta sürekli karıştırın.",
            ingredients = listOf(
                RecipeIngredient("Tarhana", 1.0, "yemek kaşığı", isMain = true),
                RecipeIngredient("Tereyağı", 0.5, "yemek kaşığı"),
                RecipeIngredient("Salça", 0.25, "yemek kaşığı"),
                RecipeIngredient("Sarımsak", 0.5, "diş"),
                RecipeIngredient("Nane", 0.25, "tatlı kaşığı")
            ),
            instructions = listOf(
                RecipeStep(1, "Tarhanayı 1 su bardağı ılık suda 5 dakika yumuşatın.", 5),
                RecipeStep(2, "Tencerede tereyağında salça ve ezilmiş sarımsağı kokusu çıkana dek kavurun.", 3),
                RecipeStep(3, "Yumuşamış tarhanayı ve 4 su bardağı suyu ekleyin.", 2),
                RecipeStep(4, "Kaynayana kadar tel çırpıcıyla sürekli karıştırarak pişirin.", 8),
                RecipeStep(5, "Kuru nane ve tuzunu ekleyip sıcak sıcak kaselere paylaştırın.", 2)
            )
        ),
        RecipeItem(
            id = "rec_kuru_fasulye",
            title = "Geleneksel Kuru Fasulye",
            description = "Lokanta kıvamında, helmelenmiş suyunda pişmiş tam kıvamında enfes kuru fasulye.",
            category = "Sebze & Zeytinyağlı",
            mealType = "Akşam",
            dietType = "Etsiz",
            prepTimeMinutes = 15,
            cookTimeMinutes = 40,
            difficulty = "Orta",
            baseServings = 4,
            emoji = "🫘",
            caloriesApprox = 320,
            tips = "Fasulyeleri bir gece önceden ıslatmak gazını alır ve pamuk gibi pişmesini sağlar. Yanına tereyağlı pirinç pilavı çok yakışır.",
            ingredients = listOf(
                RecipeIngredient("Kuru fasulye", 0.5, "su bardağı", isMain = true),
                RecipeIngredient("Soğan", 0.25, "adet", isMain = true),
                RecipeIngredient("Biber", 0.5, "adet"),
                RecipeIngredient("Salça", 0.5, "yemek kaşığı"),
                RecipeIngredient("Zeytinyağı", 0.5, "yemek kaşığı"),
                RecipeIngredient("Tereyağı", 0.25, "yemek kaşığı")
            ),
            instructions = listOf(
                RecipeStep(1, "Önceden ıslatılmış fasulyeleri düdüklüde veya tencerede hafif haşlayın.", 15),
                RecipeStep(2, "Ayrı tencerede yağda doğranmış soğan ve biberi pembeleşinceye kadar kavurun.", 5),
                RecipeStep(3, "Salçayı ekleyip kokusu çıkana kadar 2 dakika daha kavurun.", 2),
                RecipeStep(4, "Fasulyeleri ve üzerini 2 parmak geçecek sıcak suyu ekleyip kısık ateşte pişirin.", 25),
                RecipeStep(5, "Fasulyeler yumuşayıp suyu özleşince ocaktan alın, 10 dakika dinlendirin.", 10)
            )
        ),
        RecipeItem(
            id = "rec_karniyarik",
            title = "Karnıyarık",
            description = "Fırında köz gibi kızarmış patlıcanların arasına doldurulan nefis kıymalı harç.",
            category = "Et & Tavuk",
            mealType = "Akşam",
            dietType = "Normal",
            prepTimeMinutes = 20,
            cookTimeMinutes = 35,
            difficulty = "Orta",
            baseServings = 4,
            emoji = "🍆",
            caloriesApprox = 390,
            tips = "Patlıcanları alacalı soyup tuzlu suda bekletirseniz acısı çıkar ve daha az yağ çeker.",
            ingredients = listOf(
                RecipeIngredient("Patlıcan", 1.0, "adet", isMain = true),
                RecipeIngredient("Kıyma", 75.0, "gram", isMain = true),
                RecipeIngredient("Soğan", 0.25, "adet"),
                RecipeIngredient("Domates", 0.5, "adet"),
                RecipeIngredient("Biber", 0.5, "adet"),
                RecipeIngredient("Sarımsak", 0.5, "diş"),
                RecipeIngredient("Salça", 0.25, "yemek kaşığı")
            ),
            instructions = listOf(
                RecipeStep(1, "Patlıcanları alacalı soyup ortasından boyuna çizik atın ve kızartın.", 12),
                RecipeStep(2, "Tavada soğan, kıyma, sarımsak ve biberi suyunu çekene kadar kavurun.", 10),
                RecipeStep(3, "Doğranmış domates, salça ve baharatları ekleyip 5 dakika pişirin.", 5),
                RecipeStep(4, "Patlıcanların yarıklarını kaşıkla açıp hazırladığınız kıymalı harçla doldurun.", 5),
                RecipeStep(5, "Tepsiye dizip salçalı sıcak su dökün ve 180 derece fırında 20 dakika pişirin.", 20)
            )
        ),
        RecipeItem(
            id = "rec_anne_koftesi",
            title = "Klasik Anne Köftesi & Patates",
            description = "Yumuşacık, içi sulu kalan anne eli değmiş nefis ızgara köfte ve elma dilim patates.",
            category = "Et & Tavuk",
            mealType = "Akşam",
            dietType = "Normal",
            prepTimeMinutes = 15,
            cookTimeMinutes = 15,
            difficulty = "Kolay",
            baseServings = 4,
            emoji = "🧆",
            caloriesApprox = 420,
            tips = "Köfte harcını en az 10 dakika yoğurup buzdolabında 20 dakika dinlendirirseniz dağılmaz ve puf puf kabarır.",
            ingredients = listOf(
                RecipeIngredient("Kıyma", 125.0, "gram", isMain = true),
                RecipeIngredient("Soğan", 0.25, "adet"),
                RecipeIngredient("Ekmek içi", 0.25, "dilim"),
                RecipeIngredient("Yumurta", 0.25, "adet"),
                RecipeIngredient("Sarımsak", 0.25, "diş"),
                RecipeIngredient("Patates", 0.75, "adet", isMain = true),
                RecipeIngredient("Kimyon & Karabiber", 0.25, "tatlı kaşığı")
            ),
            instructions = listOf(
                RecipeStep(1, "Rendelenmiş soğan, kıyma, ufalanmış ekmek içi, yumurta ve baharatları geniş kapta yoğurun.", 10),
                RecipeStep(2, "Köfte harcından ceviz büyüklüğünde parçalar koparıp yassı şekil verin.", 5),
                RecipeStep(3, "Patatesleri elma dilim doğrayıp zeytinyağı ve tuz ile harmanlayın.", 5),
                RecipeStep(4, "Döküm tavada veya fırında köfteleri arkalı önlü nar gibi kızarana kadar pişirin.", 12),
                RecipeStep(5, "Kızaran patateslerle birlikte sıcak sıcak servis yapın.", 2)
            )
        ),
        RecipeItem(
            id = "rec_tavuklu_pilav",
            title = "Tavuklu Nohutlu Sokak Pilavı",
            description = "Tane tane dökülen tereyağlı pirinç pilavı üzerinde tiftiklenmiş leziz tavuk ve haşlanmış nohut.",
            category = "Et & Tavuk",
            mealType = "Akşam",
            dietType = "Normal",
            prepTimeMinutes = 10,
            cookTimeMinutes = 25,
            difficulty = "Kolay",
            baseServings = 4,
            emoji = "🍗",
            caloriesApprox = 450,
            tips = "Pirinci ılık tuzlu suda 20 dakika bekletip nişastası gidene kadar iyice yıkayın.",
            ingredients = listOf(
                RecipeIngredient("Tavuk", 100.0, "gram", isMain = true),
                RecipeIngredient("Pirinç", 0.5, "su bardağı", isMain = true),
                RecipeIngredient("Nohut", 0.25, "su bardağı"),
                RecipeIngredient("Tereyağı", 0.75, "yemek kaşığı"),
                RecipeIngredient("Sıvı yağ", 0.5, "yemek kaşığı"),
                RecipeIngredient("Karabiber", 0.25, "tatlı kaşığı")
            ),
            instructions = listOf(
                RecipeStep(1, "Tavuk etini tuzlu suda haşlayın, suyunu süzüp kenara ayırın ve etleri didikleyin.", 20),
                RecipeStep(2, "Tencerede yağları eritip yıkanmış pirinci şeffaflaşana kadar kavurun.", 6),
                RecipeStep(3, "Haşlanmış nohutları ve sıcak tavuk suyunu (pirincin 1.5 katı) ilave edin.", 3),
                RecipeStep(4, "Kısık ateşte suyunu çekene kadar kapağı kapalı olarak pişirin.", 15),
                RecipeStep(5, "Üzerine kağıt havlu koyup 15 dakika demlendirin; tiftik tavuk ve karabiberle servis edin.", 15)
            )
        ),
        RecipeItem(
            id = "rec_menemen",
            title = "Geleneksel Menemen",
            description = "Sabah kahvaltılarının ve pratik akşamların kurtarıcısı, ekmek banmalık sulu sulu menemen.",
            category = "Pratik & Hızlı",
            mealType = "Kahvaltı",
            dietType = "Vejetaryen",
            prepTimeMinutes = 5,
            cookTimeMinutes = 10,
            difficulty = "Kolay",
            baseServings = 2,
            emoji = "🍳",
            caloriesApprox = 210,
            tips = "Domateslerin kabuğunu soyup ince doğrayın; yumurtaları çok fazla kurutmadan hafif sulu bırakın.",
            ingredients = listOf(
                RecipeIngredient("Yumurta", 1.5, "adet", isMain = true),
                RecipeIngredient("Domates", 1.5, "adet", isMain = true),
                RecipeIngredient("Biber", 1.5, "adet", isMain = true),
                RecipeIngredient("Tereyağı", 0.5, "yemek kaşığı"),
                RecipeIngredient("Sıvı yağ", 0.5, "yemek kaşığı"),
                RecipeIngredient("Tuz & Pul biber", 0.5, "tatlı kaşığı")
            ),
            instructions = listOf(
                RecipeStep(1, "Biberleri ince ince doğrayıp tavada sıvı yağ ve tereyağında kavurun.", 3),
                RecipeStep(2, "Kabukları soyulup küp doğranmış domatesleri ekleyin.", 2),
                RecipeStep(3, "Domatesler suyunu salıp çekene kadar kısık ateşte pişirin.", 6),
                RecipeStep(4, "Yumurtaları kırıp tuzunu serpin, spatula ile hafifçe sarılarını dağıtın.", 3),
                RecipeStep(5, "İstediğiniz kıvama gelince ocaktan alıp sıcak ekmekle servis edin.", 1)
            )
        ),
        RecipeItem(
            id = "rec_tavuk_sote",
            title = "Renkli Biberli Tavuk Sote",
            description = "Lokum gibi pişen tavuk parçaları, renkli biberler ve hafif domates sosuyla nefis akşam yemeği.",
            category = "Et & Tavuk",
            mealType = "Akşam",
            dietType = "Normal",
            prepTimeMinutes = 10,
            cookTimeMinutes = 15,
            difficulty = "Kolay",
            baseServings = 4,
            emoji = "🥘",
            caloriesApprox = 290,
            tips = "Tavayı iyice kızdırdıktan sonra tavukları atarsanız suyunu içine hapseder ve pamuk gibi olur.",
            ingredients = listOf(
                RecipeIngredient("Tavuk göğsü", 125.0, "gram", isMain = true),
                RecipeIngredient("Biber", 0.75, "adet"),
                RecipeIngredient("Domates", 0.5, "adet"),
                RecipeIngredient("Soğan", 0.25, "adet"),
                RecipeIngredient("Sarımsak", 0.5, "diş"),
                RecipeIngredient("Zeytinyağı", 0.5, "yemek kaşığı"),
                RecipeIngredient("Kekik & Pul biber", 0.25, "tatlı kaşığı")
            ),
            instructions = listOf(
                RecipeStep(1, "Tavukları kuşbaşı doğrayın. İyice ısınmış tavada yüksek ateşte soteleyin.", 6),
                RecipeStep(2, "Yemeklik doğranmış soğan, sarımsak ve biberleri tavuğa ekleyin.", 4),
                RecipeStep(3, "Biberler yumuşayınca küp domatesleri ve baharatları ilave edin.", 3),
                RecipeStep(4, "Tavanın kapağını kapatıp kısık ateşte 8-10 dakika pişmeye bırakın.", 8),
                RecipeStep(5, "Ocaktan almadan önce bol kekik serpip pilav eşliğinde sunun.", 1)
            )
        ),
        RecipeItem(
            id = "rec_kiymali_makarna",
            title = "Kıymalı Bolonez Usulü Türk Makarnası",
            description = "Hızlı, doyurucu ve herkesin bayıldığı bol lezzetli kıymalı ev makarnası.",
            category = "Pratik & Hızlı",
            mealType = "Akşam",
            dietType = "Normal",
            prepTimeMinutes = 5,
            cookTimeMinutes = 12,
            difficulty = "Kolay",
            baseServings = 4,
            emoji = "🍝",
            caloriesApprox = 380,
            tips = "Makarnayı haşlarken suyundan yarım kepçe ayırıp kıymalı sosa eklerseniz sos makarnaya mükemmel yapışır.",
            ingredients = listOf(
                RecipeIngredient("Makarna", 0.25, "paket", isMain = true),
                RecipeIngredient("Kıyma", 60.0, "gram", isMain = true),
                RecipeIngredient("Soğan", 0.25, "adet"),
                RecipeIngredient("Salça", 0.5, "yemek kaşığı"),
                RecipeIngredient("Sıvı yağ", 0.5, "yemek kaşığı"),
                RecipeIngredient("Sarımsak", 0.25, "diş")
            ),
            instructions = listOf(
                RecipeStep(1, "Bol tuzlu kaynar suda makarnayı 8-10 dakika haşlayıp süzün.", 10),
                RecipeStep(2, "Ayrı tavada sıvı yağda soğan ve kıymayı suyunu çekene kadar kavurun.", 6),
                RecipeStep(3, "Salça, ezilmiş sarımsak ve az makarna haşlama suyu ekleyip sosu kaynatın.", 4),
                RecipeStep(4, "Haşlanmış makarnayı sosla buluşturup 1 dakika birlikte harmanlayın.", 2),
                RecipeStep(5, "Üzerine arzuya göre rendelenmiş kaşar veya yoğurt dökerek servis edin.", 1)
            )
        ),
        RecipeItem(
            id = "rec_zeytinyagli_taze_fasulye",
            title = "Zeytinyağlı Taze Fasulye",
            description = "Hafif, ferah, domatesin tatlılığıyla zeytinyağının buluştuğu şahane Ege tarifi.",
            category = "Sebze & Zeytinyağlı",
            mealType = "Öğle",
            dietType = "Vejetaryen",
            prepTimeMinutes = 15,
            cookTimeMinutes = 25,
            difficulty = "Kolay",
            baseServings = 4,
            emoji = "🫛",
            caloriesApprox = 150,
            tips = "Piştikten sonra tencerenin kapağını açmadan oda sıcaklığına gelmesini bekleyin, soğuk servis edin.",
            ingredients = listOf(
                RecipeIngredient("Taze fasulye", 150.0, "gram", isMain = true),
                RecipeIngredient("Domates", 0.75, "adet", isMain = true),
                RecipeIngredient("Soğan", 0.25, "adet"),
                RecipeIngredient("Zeytinyağı", 1.0, "yemek kaşığı"),
                RecipeIngredient("Şeker", 0.25, "tatlı kaşığı"),
                RecipeIngredient("Sarımsak", 0.25, "diş")
            ),
            instructions = listOf(
                RecipeStep(1, "Fasulyeleri ayıklayıp boyuna ikiye veya üçe kesin.", 10),
                RecipeStep(2, "Tencereye zeytinyağı, yemeklik doğranmış soğan ve sarımsağı koyup hafif sarartın.", 4),
                RecipeStep(3, "Fasulyeleri ve üzerine rendelenmiş domatesleri, tuz ve şekeri yayın.", 3),
                RecipeStep(4, "Kısık ateşte kendi buharında fasulyeler yumuşayana kadar pişirin.", 25),
                RecipeStep(5, "Oda sıcaklığına gelince buzdolabında soğutup limonla servis edin.", 5)
            )
        ),
        RecipeItem(
            id = "rec_kabak_mucveri",
            title = "Fırında veya Tavada Kabak Mücveri",
            description = "Dereotu, beyaz peynir ve taze kabağın efsane lezzeti. İçi yumuşak dışı çıtır.",
            category = "Sebze & Zeytinyağlı",
            mealType = "Öğle",
            dietType = "Vejetaryen",
            prepTimeMinutes = 15,
            cookTimeMinutes = 15,
            difficulty = "Kolay",
            baseServings = 4,
            emoji = "🥒",
            caloriesApprox = 190,
            tips = "Kabakları rendeledikten sonra suyunu avucunuzla iyice sıkın, böylece mücver sulanmaz ve çıtır olur.",
            ingredients = listOf(
                RecipeIngredient("Kabak", 0.75, "adet", isMain = true),
                RecipeIngredient("Yumurta", 0.5, "adet", isMain = true),
                RecipeIngredient("Beyaz peynir", 30.0, "gram"),
                RecipeIngredient("Un", 0.75, "yemek kaşığı"),
                RecipeIngredient("Dereotu & Maydanoz", 0.25, "demet"),
                RecipeIngredient("Sıvı yağ", 0.5, "yemek kaşığı")
            ),
            instructions = listOf(
                RecipeStep(1, "Kabakları rendeleyip avucunuzda sıkarak fazla suyunu tamamen çıkarın.", 8),
                RecipeStep(2, "Geniş kapta kabak, yumurta, un, ezilmiş peynir ve ince kıyılmış yeşillikleri karıştırın.", 5),
                RecipeStep(3, "Tavada az yağı ısıtıp kaşıkla karışımdan dökerek arkalı önlü kızartın (veya 190C fırında pişirin).", 10),
                RecipeStep(4, "Kağıt havlu üzerine alıp fazla yağını süzdürün.", 2),
                RecipeStep(5, "Sarımsaklı yoğurt eşliğinde servis edin.", 2)
            )
        ),
        RecipeItem(
            id = "rec_saksuka",
            title = "Hakiki Şakşuka",
            description = "Kızarmış patlıcan ve biberlerin enfes sarımsaklı domates sosuyla taçlandırıldığı meze.",
            category = "Sebze & Zeytinyağlı",
            mealType = "Öğle",
            dietType = "Vejetaryen",
            prepTimeMinutes = 15,
            cookTimeMinutes = 15,
            difficulty = "Kolay",
            baseServings = 4,
            emoji = "🍆",
            caloriesApprox = 210,
            tips = "Domates sosuna bir çay kaşığı sirke eklerseniz lokanta lezzetini yakalarsınız.",
            ingredients = listOf(
                RecipeIngredient("Patlıcan", 0.75, "adet", isMain = true),
                RecipeIngredient("Biber", 0.75, "adet"),
                RecipeIngredient("Domates", 0.75, "adet", isMain = true),
                RecipeIngredient("Sarımsak", 0.75, "diş"),
                RecipeIngredient("Zeytinyağı", 0.75, "yemek kaşığı"),
                RecipeIngredient("Sirke", 0.25, "tatlı kaşığı")
            ),
            instructions = listOf(
                RecipeStep(1, "Patlıcanları ve biberleri küp doğrayıp zeytinyağında kızartın.", 10),
                RecipeStep(2, "Ayrı tavada rendelenmiş domates, ezilmiş sarımsak, tuz ve sirkeyi koyulaşana dek kaynatın.", 8),
                RecipeStep(3, "Kızaran sebzeleri servis tabağına alın.", 2),
                RecipeStep(4, "Sıcak domates sosunu sebzelerin üzerine gezdirin.", 2),
                RecipeStep(5, "Ilık veya soğuk olarak ikram edin.", 1)
            )
        ),
        RecipeItem(
            id = "rec_sigara_boregi",
            title = "Çıtır Peynirli Sigara Böreği",
            description = "İçi eriyen böreklik peynir ve maydanoz dolgulu, altın sarısı çıtır börekler.",
            category = "Hamur İşi & Börek",
            mealType = "Atıştırmalık",
            dietType = "Vejetaryen",
            prepTimeMinutes = 10,
            cookTimeMinutes = 10,
            difficulty = "Kolay",
            baseServings = 4,
            emoji = "🥟",
            caloriesApprox = 260,
            tips = "Yufkaların ucunu suyla ıslatarak yapıştırırsanız kızartırken açılmaz ve peynir taşmaz.",
            ingredients = listOf(
                RecipeIngredient("Yufka", 0.5, "adet", isMain = true),
                RecipeIngredient("Beyaz peynir / Lor", 50.0, "gram", isMain = true),
                RecipeIngredient("Maydanoz", 0.2, "demet"),
                RecipeIngredient("Sıvı yağ", 1.0, "yemek kaşığı")
            ),
            instructions = listOf(
                RecipeStep(1, "Yufkayı üçgen parçalara bölün (üçgen dilimler).", 3),
                RecipeStep(2, "Geniş kenarına peynir ve kıyılmış maydanoz karışımını yayın.", 3),
                RecipeStep(3, "Kenarları içe katlayıp rulo şeklinde sarın, ucunu suyla ıslatıp yapıştırın.", 5),
                RecipeStep(4, "Kızgın sıvı yağda altın sarısı olana kadar kızartın (veya fırında 200C'de fırınlayın).", 6),
                RecipeStep(5, "Çay yanında sıcak servis edin.", 2)
            )
        ),
        RecipeItem(
            id = "rec_firinda_makarna",
            title = "Beşamel Soslu Fırın Makarna",
            description = "Üzeri nar gibi kızarmış çıtır kaşar peyniri, kremsi beşamel sos ve fırın makarna.",
            category = "Hamur İşi & Börek",
            mealType = "Akşam",
            dietType = "Vejetaryen",
            prepTimeMinutes = 15,
            cookTimeMinutes = 30,
            difficulty = "Orta",
            baseServings = 4,
            emoji = "🧀",
            caloriesApprox = 440,
            tips = "Makarnayı hafif dişe gelecek şekilde (aldente) haşlayın çünkü fırında da pişecek.",
            ingredients = listOf(
                RecipeIngredient("Makarna", 0.25, "paket", isMain = true),
                RecipeIngredient("Süt", 0.5, "su bardağı", isMain = true),
                RecipeIngredient("Un", 0.5, "yemek kaşığı"),
                RecipeIngredient("Tereyağı", 0.5, "yemek kaşığı"),
                RecipeIngredient("Kaşar peyniri", 40.0, "gram", isMain = true)
            ),
            instructions = listOf(
                RecipeStep(1, "Fırın makarnayı bol tuzlu suda 7-8 dakika haşlayıp süzün.", 8),
                RecipeStep(2, "Sos tenceresinde tereyağında unu kokusu çıkana dek kavurun.", 3),
                RecipeStep(3, "Sütü yavaşça ekleyerek tel çırpıcıyla koyulaşana kadar pişirin (beşamel sos).", 6),
                RecipeStep(4, "Makarnayı beşamel sosla harmanlayıp borcama dökün, üzerine bol kaşar rendeleyin.", 4),
                RecipeStep(5, "200 derece fırında üzeri altın sarısı kızarana dek 20-25 dakika fırınlayın.", 25)
            )
        ),
        RecipeItem(
            id = "rec_kayseri_mantisi",
            title = "Klasik Kayseri Mantısı",
            description = "Yoğurt, sarımsak ve tereyağlı nane-pul biber soslu şahane geleneksel mantı ziyafeti.",
            category = "Hamur İşi & Börek",
            mealType = "Akşam",
            dietType = "Normal",
            prepTimeMinutes = 20,
            cookTimeMinutes = 15,
            difficulty = "Zor",
            baseServings = 4,
            emoji = "🥟",
            caloriesApprox = 480,
            tips = "Sosundaki tereyağını yakmadan pul biber ve naneyi kokusu çıkınca hemen ocaktan alın.",
            ingredients = listOf(
                RecipeIngredient("Mantı", 120.0, "gram", isMain = true),
                RecipeIngredient("Yoğurt", 0.5, "su bardağı", isMain = true),
                RecipeIngredient("Sarımsak", 0.5, "diş"),
                RecipeIngredient("Tereyağı", 0.75, "yemek kaşığı"),
                RecipeIngredient("Salça", 0.25, "tatlı kaşığı"),
                RecipeIngredient("Nane & Sumak", 0.25, "tatlı kaşığı")
            ),
            instructions = listOf(
                RecipeStep(1, "Tencerede bol tuzlu suyu kaynatın, mantıları atıp 10-12 dakika haşlayın.", 12),
                RecipeStep(2, "Sarımsakları ezip yoğurt ile homojen bir sos hazırlayın.", 3),
                RecipeStep(3, "Küçük tavada tereyağını eritip salça, nane ve pul biberi hafif kızdırın.", 4),
                RecipeStep(4, "Haşlanan mantıyı süzüp servis tabaklarına paylaştırın.", 2),
                RecipeStep(5, "Üzerine önce sarımsaklı yoğurt, ardından kızgın tereyağı sosu döküp sumak serpin.", 2)
            )
        ),
        RecipeItem(
            id = "rec_mercimek_koftesi",
            title = "Limonlu Mercimek Köftesi",
            description = "İnce bulgur, kırmızı mercimek ve bol yeşillikle yapılan en sevilen Türk ikramlığı.",
            category = "Hafif & Diyet",
            mealType = "Atıştırmalık",
            dietType = "Vejetaryen",
            prepTimeMinutes = 15,
            cookTimeMinutes = 15,
            difficulty = "Kolay",
            baseServings = 4,
            emoji = "🧆",
            caloriesApprox = 230,
            tips = "Sıcak mercimeğin üzerine bulguru ekleyip kapağı kapatarak şişmeye bırakmak köftenin harcını mükemmel yapar.",
            ingredients = listOf(
                RecipeIngredient("Kırmızı mercimek", 0.25, "su bardağı", isMain = true),
                RecipeIngredient("İnce bulgur", 0.25, "su bardağı", isMain = true),
                RecipeIngredient("Soğan", 0.25, "adet"),
                RecipeIngredient("Salça", 0.5, "yemek kaşığı"),
                RecipeIngredient("Zeytinyağı", 0.75, "yemek kaşığı"),
                RecipeIngredient("Taze soğan & Maydanoz", 0.25, "demet"),
                RecipeIngredient("Limon", 0.25, "adet")
            ),
            instructions = listOf(
                RecipeStep(1, "Mercimeği 1.5 su bardağı suda iyice yumuşayana kadar haşlayın.", 15),
                RecipeStep(2, "Ocağı kapatıp ince bulguru ekleyin, karıştırıp kapağını kapatıp 15 dakika şişirin.", 15),
                RecipeStep(3, "Tavada zeytinyağında ince soğan ve salçayı kavurup mercimekli harca ekleyin.", 5),
                RecipeStep(4, "Harç ılıyınca ince kıyılmış maydanoz, taze soğan, limon suyu ve baharatları ekleyip yoğurun.", 6),
                RecipeStep(5, "Avuç içinde sıkarak parmak izli köfte şekli verip marul yaprakları üzerinde servis edin.", 5)
            )
        ),
        RecipeItem(
            id = "rec_bulgur_pilavi",
            title = "Meyhane Usulü Domatesli Bulgur Pilavı",
            description = "Bol domatesli, biberli ve tereyağlı geleneksel köy usulü bulgur pilavı.",
            category = "Pratik & Hızlı",
            mealType = "Akşam",
            dietType = "Vejetaryen",
            prepTimeMinutes = 5,
            cookTimeMinutes = 18,
            difficulty = "Kolay",
            baseServings = 4,
            emoji = "🍚",
            caloriesApprox = 260,
            tips = "Bulguru kavururken ezmemeye özen gösterin, kısık ateşte suyunu çekince kapağın altına havlu koyup dinlendirin.",
            ingredients = listOf(
                RecipeIngredient("Pilavlık bulgur", 0.5, "su bardağı", isMain = true),
                RecipeIngredient("Soğan", 0.25, "adet"),
                RecipeIngredient("Biber", 0.5, "adet"),
                RecipeIngredient("Domates", 0.5, "adet"),
                RecipeIngredient("Salça", 0.25, "yemek kaşığı"),
                RecipeIngredient("Tereyağı", 0.5, "yemek kaşığı")
            ),
            instructions = listOf(
                RecipeStep(1, "Tencerede tereyağında yemeklik soğan ve biberleri kavurun.", 4),
                RecipeStep(2, "Salçayı ve rendelenmiş domatesi ekleyip 3 dakika pişirin.", 3),
                RecipeStep(3, "Yıkanmış bulguru ilave edip 2 dakika harmanlayarak kavurun.", 2),
                RecipeStep(4, "1 su bardağı sıcak su ve tuz ekleyip kısık ateşte suyunu çekene dek pişirin.", 15),
                RecipeStep(5, "10 dakika demlendirip sıcak sıcak servis yapın.", 10)
            )
        ),
        RecipeItem(
            id = "rec_firinda_sutlac",
            title = "Fırında Anne Sütlacı",
            description = "Üzeri nar gibi yanık kabuklu, içi ipeksi kıvamda tam ölçülü nefis fırın sütlaç.",
            category = "Tatlı",
            mealType = "Atıştırmalık",
            dietType = "Vejetaryen",
            prepTimeMinutes = 10,
            cookTimeMinutes = 35,
            difficulty = "Kolay",
            baseServings = 4,
            emoji = "🍮",
            caloriesApprox = 240,
            tips = "Güveçleri fırın tepsisine dizip tepsiye yarısına kadar soğuk su koyarsanız altı pişmeden sadece üstü mükemmel kızarır.",
            ingredients = listOf(
                RecipeIngredient("Süt", 1.0, "su bardağı", isMain = true),
                RecipeIngredient("Pirinç", 0.15, "çay bardağı", isMain = true),
                RecipeIngredient("Şeker", 0.25, "su bardağı"),
                RecipeIngredient("Nişasta", 0.5, "tatlı kaşığı"),
                RecipeIngredient("Vanilin", 0.25, "paket")
            ),
            instructions = listOf(
                RecipeStep(1, "Pirinci 1 su bardağı suda suyunu çekip yumuşayana kadar haşlayın.", 12),
                RecipeStep(2, "Sütü ve şekeri ekleyip kaynamaya bırakın.", 8),
                RecipeStep(3, "Az suyla açılmış nişastayı ve vanilini ekleyip 5 dakika koyulaşana kadar karıştırın.", 5),
                RecipeStep(4, "Sütlacı fırın güveçlerine paylaştırıp içi su dolu tepsiye dizin.", 3),
                RecipeStep(5, "Fırının sadece üst ızgarasını (200C) açıp üzeri kızarana dek 15 dakika fırınlayın.", 15)
            )
        ),
        RecipeItem(
            id = "rec_patates_oturtma",
            title = "Fırında Kıymalı Patates Oturtma",
            description = "Yuvarlak dilimlenmiş patateslerin leziz kıymalı harçla fırında buluşması.",
            category = "Et & Tavuk",
            mealType = "Akşam",
            dietType = "Normal",
            prepTimeMinutes = 15,
            cookTimeMinutes = 35,
            difficulty = "Orta",
            baseServings = 4,
            emoji = "🥔",
            caloriesApprox = 370,
            tips = "Patatesleri çok kalın dilimlemeyin ki fırında içi pamuk gibi pişsin.",
            ingredients = listOf(
                RecipeIngredient("Patates", 1.0, "adet", isMain = true),
                RecipeIngredient("Kıyma", 70.0, "gram", isMain = true),
                RecipeIngredient("Soğan", 0.25, "adet"),
                RecipeIngredient("Biber", 0.5, "adet"),
                RecipeIngredient("Salça", 0.5, "yemek kaşığı"),
                RecipeIngredient("Zeytinyağı", 0.5, "yemek kaşığı")
            ),
            instructions = listOf(
                RecipeStep(1, "Patatesleri soyup halka halka dilimleyin ve tepsinin tabanına dizin.", 5),
                RecipeStep(2, "Tavada yağda soğan, biber ve kıymayı suyunu çekene dek kavurun.", 8),
                RecipeStep(3, "Salça, tuz ve baharatları ekleyip yarım çay bardağı suyla 2 dakika pişirin.", 3),
                RecipeStep(4, "Kıymalı harcı patateslerin üzerine eşit şekilde yayın.", 3),
                RecipeStep(5, "1 çay bardağı salçalı sıcak su ekleyip 190 derece fırında 30 dakika pişirin.", 30)
            )
        ),
        RecipeItem(
            id = "rec_ispanak_yemegi",
            title = "Pirinçli Kıymalı Ispanak Yemeği",
            description = "Bol vitaminli taze ıspanak, pirinç ve kıymanın sarımsaklı yoğurtla şöleni.",
            category = "Sebze & Zeytinyağlı",
            mealType = "Akşam",
            dietType = "Normal",
            prepTimeMinutes = 15,
            cookTimeMinutes = 20,
            difficulty = "Kolay",
            baseServings = 4,
            emoji = "🥬",
            caloriesApprox = 220,
            tips = "Ispanakları sirkeli suda birkaç kez yıkayıp kumundan tamamen arındırın.",
            ingredients = listOf(
                RecipeIngredient("Ispanak", 150.0, "gram", isMain = true),
                RecipeIngredient("Kıyma", 40.0, "gram"),
                RecipeIngredient("Pirinç", 0.1, "çay bardağı"),
                RecipeIngredient("Soğan", 0.25, "adet"),
                RecipeIngredient("Salça", 0.25, "yemek kaşığı"),
                RecipeIngredient("Yoğurt", 0.25, "su bardağı")
            ),
            instructions = listOf(
                RecipeStep(1, "Tencerede soğan ve kıymayı zeytinyağında kavurun.", 5),
                RecipeStep(2, "Salçayı ekleyip kokusu çıkınca doğranmış ıspanakları peyderpey ilave edin.", 4),
                RecipeStep(3, "Ispanaklar sönünce yıkanmış pirinci ve yarım su bardağı sıcak suyu ekleyin.", 3),
                RecipeStep(4, "Kısık ateşte pirinçler yumuşayana dek kapağı kapalı 15 dakika pişirin.", 15),
                RecipeStep(5, "Yanında sarımsaklı yoğurtla servis edin.", 2)
            )
        ),
        RecipeItem(
            id = "rec_koz_patlican_salatasi",
            title = "Köz Patlıcan Salatası",
            description = "Dumanı üstünde közlenmiş patlıcan, sarımsak, zeytinyağı ve taze limon suyu.",
            category = "Hafif & Diyet",
            mealType = "Öğle",
            dietType = "Vejetaryen",
            prepTimeMinutes = 10,
            cookTimeMinutes = 10,
            difficulty = "Kolay",
            baseServings = 4,
            emoji = "🍆",
            caloriesApprox = 90,
            tips = "Patlıcanları ocak üstünde veya fırında közledikten sonra buzdolabı poşetine koyup ağzını bağlarsanız kabukları tek hamlede soyulur.",
            ingredients = listOf(
                RecipeIngredient("Patlıcan", 1.0, "adet", isMain = true),
                RecipeIngredient("Kırmızı biber", 0.5, "adet"),
                RecipeIngredient("Sarımsak", 0.5, "diş"),
                RecipeIngredient("Zeytinyağı", 0.75, "yemek kaşığı"),
                RecipeIngredient("Limon", 0.25, "adet")
            ),
            instructions = listOf(
                RecipeStep(1, "Patlıcan ve kırmızı biberi közleyin, kabuklarını soyup ince ince kıyın.", 10),
                RecipeStep(2, "Kasede ezilmiş sarımsak, zeytinyağı, limon suyu ve tuzu çırpın.", 3),
                RecipeStep(3, "Közlenmiş sebzeleri sosla harmanlayıp servis tabağına alın.", 2),
                RecipeStep(4, "İsteğe göre üzerine maydanoz serperek soğuk servis yapın.", 1)
            )
        ),
        RecipeItem(
            id = "rec_irmik_helvasi",
            title = "Geleneksel Tereyağlı İrmik Helvası",
            description = "Tane tane dökülen, nefis süt şerbetli ve çam fıstıklı nostaljik irmik helvası.",
            category = "Tatlı",
            mealType = "Atıştırmalık",
            dietType = "Vejetaryen",
            prepTimeMinutes = 5,
            cookTimeMinutes = 15,
            difficulty = "Kolay",
            baseServings = 4,
            emoji = "🍯",
            caloriesApprox = 310,
            tips = "İrmiği kısık ateşte sabırla karamel rengi alana kadar kavurursanız rengi ve aroması harika olur.",
            ingredients = listOf(
                RecipeIngredient("İrmik", 0.5, "su bardağı", isMain = true),
                RecipeIngredient("Tereyağı", 1.0, "yemek kaşığı", isMain = true),
                RecipeIngredient("Süt", 0.5, "su bardağı"),
                RecipeIngredient("Şeker", 0.35, "su bardağı")
            ),
            instructions = listOf(
                RecipeStep(1, "Küçük tencerede süt ve şekeri şeker eriyene kadar ısıtın (kaynatmayın).", 4),
                RecipeStep(2, "Geniş tencerede tereyağını eritip irmiği kısık ateşte rengi dönene dek kavurun.", 10),
                RecipeStep(3, "Ilık sütlü şerbeti irmiğe dikkatlice dökün (sıçrayabilir, tencere kapağını siper edin).", 2),
                RecipeStep(4, "Kısık ateşte şerbeti tamamen çekene kadar karıştırıp ocaktan alın.", 3),
                RecipeStep(5, "Kapağın altına kağıt havlu koyup 15 dakika dinlendirin ve ılık servis yapın.", 15)
            )
        )
    )

    // Helper to find by ID
    fun getRecipeById(id: String): RecipeItem? = allRecipes.find { it.id == id }

    // Common pantry ingredients list for the Interactive Tag Cloud
    val commonPantryIngredients: List<String> = listOf(
        "Tavuk", "Kıyma", "Patates", "Soğan", "Domates",
        "Yumurta", "Makarna", "Pirinç", "Peynir", "Kırmızı mercimek",
        "Biber", "Yoğurt", "Sarımsak", "Patlıcan", "Havuç",
        "Kuru fasulye", "Taze fasulye", "Kabak", "Ispanak", "Nohut",
        "İnce bulgur", "Pilavlık bulgur", "Yufka", "Süt", "İrmik"
    )

    val categories: List<String> = listOf(
        "Tümü", "Çorba", "Et & Tavuk", "Sebze & Zeytinyağlı",
        "Hamur İşi & Börek", "Pratik & Hızlı", "Hafif & Diyet", "Tatlı"
    )
}
