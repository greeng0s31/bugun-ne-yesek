package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.TurkishRecipesData
import com.example.data.model.RecipeIngredient
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Bugün Ne Yesek", appName)
  }

  @Test
  fun `recipes dataset is populated with diverse Turkish meals`() {
    val recipes = TurkishRecipesData.allRecipes
    assertTrue("At least 15 recipes must be defined", recipes.size >= 15)
    assertTrue("Has soup category", recipes.any { it.category == "Çorba" })
    assertTrue("Has meat/chicken category", recipes.any { it.category == "Et & Tavuk" })
    assertTrue("Has vegetable category", recipes.any { it.category == "Sebze & Zeytinyağlı" })
  }

  @Test
  fun `recipe ingredient scaling works accurately`() {
    val ing = RecipeIngredient(name = "Kırmızı mercimek", amountPerServing = 0.25, unit = "su bardağı", isMain = true)
    assertEquals("1 su bardağı", ing.getScaledAmount(4))
    assertEquals("2 su bardağı", ing.getScaledAmount(8))
    assertEquals("1/2 su bardağı", ing.getScaledAmount(2))
  }
}
